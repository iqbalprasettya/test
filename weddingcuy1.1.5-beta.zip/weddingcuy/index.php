<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WeddingCuy</title>

    <style>
        <?php
        include "assets/css/style.css";
        ?>
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />


</head>

<body>
    <nav id="navbar" class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">WeddingCuy</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav mx-auto">
                    <a class="nav-link mx-2" href="#home">Home</a>
                    <a class="nav-link mx-2" href="#about">About</a>
                    <a class="nav-link mx-2" href="#gallery">Gallery</a>
                    <a class="nav-link mx-2" href="#">Client</a>
                    <a class="nav-link mx-2" href="#">Contact</a>
                </div>
                <a href="" id="btn-hero" class="btn-hero">Login</a>
            </div>

        </div>
    </nav>

    <div id="home" class="background-banner">
        <div class="hero-text">
            <div class="text-center">
                <p class="text-p">&#x1F496; Please Meet Up With Wedays</p>
                <h1>The Smart Way To <br> Plan Your Big Day</h1>
                <p class="sub-text">Experience wedding planning the way it should be <br> - intuitive, thoughtful, and personal </p><br>
                <a href="#features" class="main-btn">Watch Our Wedding</a>
            </div>
        </div>
    </div>

    <section id="features" class="features py-5">
        <div class="container">
            <div class="heading-text text-center mb-5">
                <p class="text-p">&#129321; Why Choose Us</p>
                <h4>The Best Features We Provide</h4>
                <p>Provide the main service in the form of making a wedding website with various interesting features, the prospective bride and groom</p>
            </div>
            <div class="row justify-content-center">
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-address-book"></i>
                    <h5>Accommodate Invited Guests</h5>
                </div>
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-circle-check"></i>
                    <h5>Verified Wedding Organizer</h5>
                </div>
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-clock"></i>
                    <h5>Always On Time Every Time</h5>
                </div>
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-house"></i>
                    <h5>Comfortable and Safe Indoor Place</h5>
                </div>
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-camera"></i>
                    <h5>Broadcast On Multiple Platforms</h5>
                </div>
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-shirt"></i>
                    <h5>Great Souvenirs and Gifts</h5>
                </div>
            </div>
        </div>
    </section>

    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <div class="text-center mb-4">
                    <p class="text-p">&#128075; Who Are We?</p>
                    <h4>About Us</h4>
                </div>
                <div class="row justify-content-center text-center">
                    <div class="col">
                        <p>We are a startup that stands to help couples who are ready to carry out their sacred promise to live together and build a family and have been at our best to make a deep impression. To welcome your happy day with your loved ones in starting a new.</p>
                        <div class="main-btn mt-4">Know More <i class="fa-solid fa-angle-right"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="package" class="package py-5">
        <div class="container">
            <div class="heading-text text-center mb-4">
                <p class="text-p">&#128184; Easy Packages Easy Money</p>
                <h4>Best Packages Best Pricing For You</h4>
            </div>
            <div class="row justify-content-center">
                <div class="package-item col-md-3">
                    <div class="head-package text-center">
                        <h4 class="text-uppercase mb-1">Silver Package</h4>
                        <p class="price fs-2 fw-semibold">$1200</p>
                        <br>
                    </div>
                    <div class="body-package">
                        <ul>
                            <li>Delicious Main Buffet 300 Servings</li>
                            <li>Beautiful Makeup, Luxurious Wedding Clothing</li>
                            <li>Magnificent Aisle Beautiful Decoration</li>
                            <li>Photo and Video Shooting & Exclusive Collage Album</li>
                            <li>Master Of Ceremony (MC) With A Sweet Voice</li>
                        </ul>
                        <div class="text-center">
                            <a href="" class="second-btn">See Detail Package</a>
                        </div>
                    </div>
                </div>
                <div class="package-item col-md-3">
                    <div class="head-package text-center">
                        <h4 class="text-uppercase mb-1">Silver Package</h4>
                        <p class="price fs-2 fw-semibold">$1200</p>
                        <br>
                    </div>
                    <div class="body-package">
                        <ul>
                            <li>Delicious Main Buffet 300 Servings</li>
                            <li>Beautiful Makeup, Luxurious Wedding Clothing</li>
                            <li>Magnificent Aisle Beautiful Decoration</li>
                            <li>Photo and Video Shooting & Exclusive Collage Album</li>
                            <li>Master Of Ceremony (MC) With A Sweet Voice</li>
                        </ul>
                        <div class="text-center">
                            <a href="" class="second-btn">See Detail Package</a>
                        </div>
                    </div>
                </div>
                <div class="package-item col-md-3">
                    <div class="head-package text-center">
                        <h4 class="text-uppercase mb-1">Silver Package</h4>
                        <p class="price fs-2 fw-semibold">$1200</p>
                        <br>
                    </div>
                    <div class="body-package">
                        <ul>
                            <li>Delicious Main Buffet 300 Servings</li>
                            <li>Beautiful Makeup, Luxurious Wedding Clothing</li>
                            <li>Magnificent Aisle Beautiful Decoration</li>
                            <li>Photo and Video Shooting & Exclusive Collage Album</li>
                            <li>Master Of Ceremony (MC) With A Sweet Voice</li>
                        </ul>
                        <div class="text-center">
                            <a href="" class="second-btn">See Detail Package</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="paralax">
        <div class="container">
            <div class="quote-content text-center text-white">
                <p class="quote fst-italic">“Happiness is only real when shared”</p>
                <p>- Jon Krakauer</p>
            </div>
        </div>
    </div>

    <section id="gallery" class="gallery py-5">
        <div class="container">
            <div class="heading-text text-center mb-5">
                <p class="text-p">&#128247; Our Gallery</p>
                <h4>Gallery</h4>
            </div>
            <div class="gallery-container row" data-masonry='{"percentPosition": true }'>
                <div class="gallery-item col-6 col-sm-6 col-lg-4">
                    <div class="gallery-text">
                        <h5>Lorem ipsum dolor sit amet.</h5>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </div>
                    <img src="assets/img/gallery/gallery1.jpg" alt="" class="img-fluid">
                </div>
                <div class="gallery-item col-6 col-sm-6 col-lg-4">
                    <div class="gallery-text">
                        <h5>Lorem ipsum dolor sit amet.</h5>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </div>
                    <img src="assets/img/gallery/gallery2.jpg" alt="" class="img-fluid">
                </div>
                <div class="gallery-item col-6 col-sm-6 col-lg-4">
                    <div class="gallery-text">
                        <h5>Lorem ipsum dolor sit amet.</h5>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </div>
                    <img src="assets/img/gallery/gallery3.jpg" alt="" class="img-fluid">
                </div>
                <div class="gallery-item col-6 col-sm-6 col-lg-4">
                    <div class="gallery-text">
                        <h5>Lorem ipsum dolor sit amet.</h5>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </div>
                    <img src="assets/img/gallery/gallery4.jpg" alt="" class="img-fluid">
                </div>
                <div class="gallery-item col-6 col-sm-6 col-lg-4">
                    <div class="gallery-text">
                        <h5>Lorem ipsum dolor sit amet.</h5>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </div>
                    <img src="assets/img/gallery/gallery5.jpg" alt="" class="img-fluid">
                </div>
                <div class="gallery-item col-6 col-sm-6 col-lg-4">
                    <div class="gallery-text">
                        <h5>Lorem ipsum dolor sit amet.</h5>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </div>
                    <img src="assets/img/gallery/gallery6.jpg" alt="" class="img-fluid">
                </div>
            </div>
        </div>
    </section>









    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/masonry-layout@4.2.2/dist/masonry.pkgd.min.js" integrity="sha384-GNFwBvfVxBkLMJpYMOABq3c+d3KnQxudP/mGPkzpZSTYykLBNsZEnG2D9G/X/+7D" crossorigin="anonymous" async></script>
    <script src="assets/js/script.js"></script>
</body>

</html>