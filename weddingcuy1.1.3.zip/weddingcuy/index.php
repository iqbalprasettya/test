<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WeddingCuy</title>

    <style>
        <?php
        include "assets/css/style.css";
        ?>
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">WeddingCuy</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav mx-auto">
                    <a class="nav-link mx-2" href="#">Home</a>
                    <a class="nav-link mx-2" href="#">Features</a>
                    <a class="nav-link mx-2" href="#">Pricing</a>
                </div>
                <a href="" class="btn-hero">Login</a>
            </div>

        </div>
    </nav>

    <div class="background-banner">
        <div class="hero-text">
            <div class="text-center">
                <p class="text-p"><i class="fa-solid fa-heart"></i> Please Meet Up With Wedays</p>
                <h1>The Smart Way To <br> Plan Your Big Day</h1>
                <p class="sub-text">Experience wedding planning the way it should be <br> - intuitive, thoughtful, and personal </p><br>
                <a href="" class="main-btn">Watch Our Wedding</a>
            </div>
        </div>
    </div>

    <section id="features" class="features py-5">
        <div class="container">
            <div class="heading-text text-center mb-5">
                <h4>The Best Features We Provide</h4>
                <p>Provide the main service in the form of making a wedding website with various interesting features, the prospective bride and groom</p>
            </div>
            <div class="row justify-content-center">
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-address-book"></i>
                    <h5>Accommodate Invited Guests</h5>
                </div>
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-circle-check"></i>
                    <h5>Verified Wedding Organizer</h5>
                </div>
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-clock"></i>
                    <h5>Always On Time Every Time</h5>
                </div>
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-house"></i>
                    <h5>Comfortable and Safe Indoor Place</h5>
                </div>
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-camera"></i>
                    <h5>Broadcast On Multiple Platforms</h5>
                </div>
                <div class="features-item col-md-3 text-center">
                    <i class="fa-solid fa-shirt"></i>
                    <h5>Great Souvenirs and Gifts</h5>
                </div>
            </div>
        </div>
    </section>







    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>